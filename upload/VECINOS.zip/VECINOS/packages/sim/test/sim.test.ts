import { beforeAll, describe, expect, it } from 'vitest';
import { fileURLToPath } from 'node:url';
import { loadContentFromDir } from '@vecinos/content/node';
import type { Content } from '@vecinos/content';
import {
  applyEffects, buildCirculation, createWorld, drainEvents, emissionsFromActivities, playerHome,
  tick, travelMinutes, validateBuilding, visibleParams, type World,
} from '../src';

let content: Content;
beforeAll(() => {
  const { content: c, issues } = loadContentFromDir(fileURLToPath(new URL('../../content/data', import.meta.url)));
  expect(issues).toEqual([]);
  content = c;
});

const fresh = (seed?: number): World => createWorld(content, 'slice', { seed });
const blocksOf = (w: World, kind: string) => Object.values(w.blocks).filter((b) => b.kind === kind);

describe('mundo inicial', () => {
  it('expande el edificio: 16 viviendas, 5 núcleos, 5 pasillos, portal y trasteros', () => {
    const w = fresh();
    expect(blocksOf(w, 'dwelling')).toHaveLength(16);
    expect(Object.values(w.blocks).filter((b) => b.defId === 'nucleo_comunicaciones')).toHaveLength(5);
    expect(Object.values(w.blocks).filter((b) => b.layer === 'corridor')).toHaveLength(5);
    expect(w.blocks.blk_p0_portal).toBeDefined();
    expect(w.blocks.blk_p4_d).toBeDefined();
  });

  it('solo la vivienda del jugador empieza desbloqueada, con una única estancia abierta', () => {
    const w = fresh();
    const open = blocksOf(w, 'dwelling').filter((b) => b.access === 'unlocked');
    expect(open.map((b) => b.id)).toEqual([playerHome(w)]);
    expect(open[0]!.rooms.filter((r) => r.access === 'unlocked').map((r) => r.key)).toEqual(['salon']);
    expect(blocksOf(w, 'dwelling').filter((b) => b.access === 'locked').every((b) => b.lockReason === 'for_sale')).toBe(true);
  });

  it('la vivienda del jugador depende de la semilla y nunca es una reservada para un vecino', () => {
    const homes = new Set<string>();
    for (let seed = 1; seed <= 40; seed++) {
      const w = fresh(seed);
      expect(playerHome(fresh(seed))).toBe(playerHome(w));
      expect(['blk_p1_b', 'blk_p2_b']).not.toContain(playerHome(w));
      homes.add(playerHome(w));
    }
    expect(homes.size).toBeGreaterThan(5);
  });

  it('el ascensor empieza roto y el edificio cumple las reglas de validación', () => {
    const w = fresh();
    expect(w.blocks.blk_p1_nucleo!.params.elevator_status).toBe('broken');
    expect(validateBuilding(w, content)).toEqual([]);
  });

  it('el estado es JSON puro: ida y vuelta sin pérdidas', () => {
    const w = fresh();
    expect(JSON.parse(JSON.stringify(w))).toEqual(w);
  });
});

describe('grafo de circulación', () => {
  it('con el ascensor roto se sube por escalera (más lento); arreglado, es más rápido', () => {
    const w = fresh();
    const toDoor = () => travelMinutes(buildCirculation(w, content), 'blk_p0_portal', 'blk_p4_a');
    expect(toDoor()).toBe(16); // portal→pasillo→núcleo (1+1) + 4 plantas a pie (12) + pasillo→puerta (1+1)
    applyEffects(w, content, [{ op: 'setParam', target: 'nucleo.elevator_status', value: 'ok' }]);
    expect(toDoor()).toBe(8);
  });

  it('un ascensor roto en una sola planta no cuenta como ascensor operativo en ese tramo', () => {
    const w = fresh();
    applyEffects(w, content, [{ op: 'setParam', target: 'nucleo.elevator_status', value: 'ok' }]);
    w.blocks.blk_p2_nucleo!.params.elevator_status = 'broken';
    const t = travelMinutes(buildCirculation(w, content), 'blk_p0_portal', 'blk_p4_a');
    expect(t).toBeGreaterThan(8);
    expect(Number.isFinite(t)).toBe(true);
  });
});

describe('efectos de misión', () => {
  it('completar el tutorial llama a la primera vecina y pone en marcha la misión del ascensor', () => {
    const w = fresh();
    applyEffects(w, content, content.missions.m_bienvenida!.onComplete!);
    const b = w.blocks.blk_p1_b!;
    expect(b.access).toBe('unlocked');
    expect(b.occupancy).toBe('occupied');
    expect(b.ownerId).toBe('res_cotilla_01');
    expect(b.rooms.map((r) => `${r.key}:${r.access}`)).toEqual(['salon:unlocked', 'dormitorio:locked', 'bano:locked']);
    expect(w.residents.res_cotilla_01!.present).toBe(true);
    expect(w.missions.map((m) => m.id)).toContain('m_ascensor');
    expect(drainEvents(w).map((e) => e.type)).toEqual(expect.arrayContaining(['block_unlocked', 'neighbor_arrived', 'mission_started']));
  });

  it('un piso puede ponerse a la venta sin abrir la puerta', () => {
    const w = fresh();
    applyEffects(w, content, [{ op: 'unlock', target: 'blk_p3_d', availability: { mode: 'for_sale', price: 9000 } }]);
    expect(w.blocks.blk_p3_d).toMatchObject({ access: 'locked', lockReason: 'for_sale', availability: { price: 9000 } });
  });

  it('arreglar el ascensor ajusta fondos comunes y revela el nivel 2 de parámetros', () => {
    const w = fresh();
    const home = playerHome(w);
    expect(visibleParams(w, content, home).map((p) => p.name).sort()).toEqual(['condition', 'humidity', 'soundproofing']);
    applyEffects(w, content, content.missions.m_ascensor!.onComplete!);
    expect(w.community.funds).toBe(200);
    expect(w.blocks.blk_p3_nucleo!.params.elevator_status).toBe('ok');
    expect(visibleParams(w, content, home).map((p) => p.name).sort()).toEqual(['condition', 'humidity', 'rent', 'soundproofing', 'style']);
    applyEffects(w, content, [{ op: 'hideParams', params: ['humidity'] }]);
    expect(visibleParams(w, content, home).map((p) => p.name)).not.toContain('humidity');
  });

  it('las relaciones usan los roles de la misión (chivarse enfría al niño y calienta a los padres)', () => {
    const w = fresh();
    w.residents.res_nino_01 = { ...w.residents.res_cotilla_01!, id: 'res_nino_01', relations: [] };
    const choice = content.missions.m_pintadas_ascensor!.choices!.find((c) => c.id === 'chivarse')!;
    applyEffects(w, content, choice.effects, { roles: { kid: 'res_nino_01', parent: 'res_cotilla_01' } });
    expect(w.residents[w.playerId]!.relations).toEqual([
      { with: 'res_cotilla_01', affinity: 10, trust: 0 },
      { with: 'res_nino_01', affinity: -20, trust: 0 },
    ]);
    expect(w.missions.find((m) => m.id === 'm_venganza_nino')!.startAtTick).toBe(1440);
  });
});

describe('influencias', () => {
  function partyWorld() {
    const w = fresh();
    applyEffects(w, content, [{ op: 'unlock', target: 'blk_p2_b', resident: 'res_fiestero_01' }]);
    drainEvents(w);
    return w;
  }

  it('una fiesta en el 2B se oye en los vecinos, atenuada por su aislamiento', () => {
    const w = partyWorld();
    const em = emissionsFromActivities(w, content, [{ resident: 'res_fiestero_01', activity: 'party' }]);
    expect(em).toEqual({ noise: { blk_p2_b: 0.9 } });
    tick(w, content, em);
    const n = w.channels.noise!;
    expect(n.blk_p2_a).toBeCloseTo(0.9 * 1.0 * 0.6); // al lado
    expect(n.blk_p3_b).toBeCloseTo(0.9 * 0.8 * 0.6); // encima
    expect(n.blk_p1_b).toBeCloseTo(0.9 * 0.6 * 0.6); // debajo
    expect(n.blk_p3_a).toBeCloseTo(0.9 * 0.3 * 0.6); // en diagonal
    expect(n.blk_p2_b).toBeUndefined(); // el emisor no se queja de su propio ruido
    const quejas = drainEvents(w).filter((e) => e.type === 'noise_complaint').map((e) => e.data.block);
    expect(quejas).toEqual(expect.arrayContaining(['blk_p2_a', 'blk_p3_b']));
    expect(quejas).not.toContain('blk_p1_b'); // 0.324 < umbral 0.35
  });

  it('la queja salta una sola vez mientras el ruido se mantiene, y de nuevo tras calmarse', () => {
    const w = partyWorld();
    const em = emissionsFromActivities(w, content, [{ resident: 'res_fiestero_01', activity: 'party' }]);
    const quejasDe = (block: string) => drainEvents(w).filter((e) => e.type === 'noise_complaint' && e.data.block === block).length;
    tick(w, content, em);
    expect(quejasDe('blk_p2_a')).toBe(1);
    tick(w, content, em);
    expect(quejasDe('blk_p2_a')).toBe(0);
    for (let i = 0; i < 30; i++) tick(w, content); // la fiesta termina y el ruido decae
    expect(w.channels.noise!.blk_p2_a ?? 0).toBeLessThan(0.35);
    drainEvents(w);
    tick(w, content, em);
    expect(quejasDe('blk_p2_a')).toBe(1);
  });

  it('el reloj avanza por minutos y cambia de día', () => {
    const w = fresh();
    w.clock.minute = 1439;
    tick(w, content);
    expect(w.clock).toEqual({ day: 2, minute: 0 });
  });

  it('es determinista: misma semilla y mismas emisiones, mismo estado', () => {
    const run = () => {
      const w = partyWorld();
      const em = emissionsFromActivities(w, content, [{ resident: 'res_fiestero_01', activity: 'party' }]);
      for (let i = 0; i < 120; i++) tick(w, content, i % 20 < 10 ? em : {});
      return JSON.stringify(w);
    };
    expect(run()).toBe(run());
  });
});
