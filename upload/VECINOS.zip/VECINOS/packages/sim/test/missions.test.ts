import { beforeAll, describe, expect, it } from 'vitest';
import { fileURLToPath } from 'node:url';
import { loadContentFromDir } from '@vecinos/content/node';
import type { Content } from '@vecinos/content';
import { activeObjective, createWorld, dispatch, drainEvents, playerHome, tick, type Command, type World } from '../src';

let content: Content;
beforeAll(() => {
  const { content: c, issues } = loadContentFromDir(fileURLToPath(new URL('../../content/data', import.meta.url)));
  expect(issues).toEqual([]);
  content = c;
});

const go = (w: World, cmd: Command) => dispatch(w, content, cmd);
const move = (w: World, ...blocks: string[]) => blocks.map((to) => go(w, { type: 'move', resident: w.playerId, to }));
const floorOf = (w: World, id: string) => w.blocks[id]!.cell.floor;
const types = (w: World) => drainEvents(w).map((e) => e.type);

/** Del portal al pasillo de la planta `f`, subiendo por el núcleo (escalera o ascensor). */
function toCorridor(w: World, f: number) {
  const path = ['blk_p0_pasillo', 'blk_p0_nucleo', ...Array.from({ length: f }, (_, i) => `blk_p${i + 1}_nucleo`), `blk_p${f}_pasillo`];
  for (const r of move(w, ...path)) expect(r.ok).toBe(true);
}

/** Juega el tutorial completo por órdenes y deja al jugador dentro de su vivienda. */
function playTutorial(w: World) {
  const home = playerHome(w);
  expect(go(w, { type: 'answer_call', mission: 'm_bienvenida' }).ok).toBe(true);
  toCorridor(w, floorOf(w, home));
  expect(go(w, { type: 'approach', resident: w.playerId, block: home }).ok).toBe(true);
  expect(go(w, { type: 'move', resident: w.playerId, to: home }).ok).toBe(true);
}

/** Tutorial + arreglo del ascensor + llegada de los vecinos: la misión de las pintadas queda activa. */
function reachPintadas(w: World) {
  playTutorial(w);
  go(w, { type: 'answer_call', mission: 'm_ascensor' });
  go(w, { type: 'choose', mission: 'm_ascensor', choice: 'convocar_junta' });
}

describe('tutorial por órdenes', () => {
  it('el teléfono suena al empezar la partida', () => {
    const w = createWorld(content, 'slice');
    const ev = drainEvents(w);
    expect(ev.find((e) => e.type === 'step_started')?.data).toMatchObject({ mission: 'm_bienvenida', type: 'phone_call', dialog: 'dlg_bienvenida' });
    expect(activeObjective(w, content)?.step).toMatchObject({ type: 'phone_call', dialog: 'dlg_bienvenida' });
  });

  it('los pasos avanzan solo con la orden correcta', () => {
    const w = createWorld(content, 'slice');
    const home = playerHome(w);
    expect(go(w, { type: 'approach', resident: w.playerId, block: home }).ok).toBe(false); // aún no está en esa planta
    expect(activeObjective(w, content)!.step!.type).toBe('phone_call');
    go(w, { type: 'answer_call', mission: 'm_bienvenida' });
    expect(activeObjective(w, content)!.step).toMatchObject({ type: 'reach', block: home });
    toCorridor(w, floorOf(w, home));
    const other = ['a', 'b', 'c', 'd'].map((t) => `blk_p${floorOf(w, home)}_${t}`).find((id) => id !== home)!;
    go(w, { type: 'approach', resident: w.playerId, block: other }); // otra puerta: no cuenta
    expect(activeObjective(w, content)!.step!.type).toBe('reach');
    go(w, { type: 'approach', resident: w.playerId, block: home });
    expect(activeObjective(w, content)!.step).toMatchObject({ type: 'enter', block: home });
  });

  it('completarlo llama a los vecinos y pone en marcha la misión del ascensor', () => {
    const w = createWorld(content, 'slice');
    playTutorial(w);
    const ev = types(w);
    expect(ev).toEqual(expect.arrayContaining(['mission_completed', 'neighbor_arrived', 'mission_started', 'mission_activated']));
    expect(w.missions.find((m) => m.id === 'm_bienvenida')!.state).toBe('done');
    expect(w.residents.res_cotilla_01!.location).toBe('blk_p1_b');
    expect(w.residents.res_nino_01!.present).toBe(true);
    expect(activeObjective(w, content)).toMatchObject({ mission: 'm_ascensor', step: { type: 'phone_call', dialog: 'dlg_ascensor' } });
  });
});

describe('reglas de circulación', () => {
  it('una vivienda con candado rechaza la entrada y avisa del motivo', () => {
    const w = createWorld(content, 'slice');
    toCorridor(w, 1);
    drainEvents(w);
    const r = go(w, { type: 'move', resident: w.playerId, to: 'blk_p1_c' === playerHome(w) ? 'blk_p1_d' : 'blk_p1_c' });
    expect(r).toEqual({ ok: false, reason: 'locked' });
    expect(drainEvents(w).find((e) => e.type === 'door_locked')?.data).toMatchObject({ reason: 'for_sale' });
    expect(w.residents[w.playerId]!.location).toBe('blk_p1_pasillo');
  });

  it('no se puede saltar de planta sin pasar por el núcleo', () => {
    const w = createWorld(content, 'slice');
    expect(go(w, { type: 'move', resident: w.playerId, to: 'blk_p3_nucleo' })).toEqual({ ok: false, reason: 'unreachable' });
    expect(go(w, { type: 'move', resident: w.playerId, to: 'blk_p0_nucleo' }).ok).toBe(true); // misma planta: por el pasillo
    expect(go(w, { type: 'move', resident: w.playerId, to: 'blk_p2_nucleo' }).ok).toBe(false); // salto de dos plantas
    expect(go(w, { type: 'move', resident: w.playerId, to: 'blk_p1_nucleo' }).ok).toBe(true);
  });
});

describe('misión de las pintadas en el ascensor', () => {
  it('se activa sola al arreglar el ascensor, con el niño colocado en la cabina', () => {
    const w = createWorld(content, 'slice');
    reachPintadas(w);
    const m = w.missions.find((x) => x.id === 'm_pintadas_ascensor')!;
    expect(m.state).toBe('active');
    expect(m.roles).toEqual({ kid: 'res_nino_01', parent: 'res_cotilla_01' });
    expect(w.residents.res_nino_01!.location).toBe('blk_p1_nucleo');
    expect(w.community.funds).toBe(200);
    expect(w.progress.revealedTier).toBe(2);
    expect(m.until).toBe(w.tick + 30);
  });

  it('pillarlo a tiempo abre la decisión y las consecuencias dependen de lo que elijas', () => {
    const w = createWorld(content, 'slice');
    reachPintadas(w);
    const home = playerHome(w);
    const f = floorOf(w, home);
    // sale de casa y baja hasta el núcleo de la planta 1, donde está el niño
    const down = Array.from({ length: f }, (_, i) => `blk_p${f - i}_nucleo`);
    for (const r of move(w, `blk_p${f}_pasillo`, ...down)) expect(r.ok).toBe(true);
    expect(w.missions.find((x) => x.id === 'm_pintadas_ascensor')!.state).toBe('awaiting_choice');
    expect(drainEvents(w).find((e) => e.type === 'choice_required' && e.data.mission === 'm_pintadas_ascensor')?.data.choices).toHaveLength(4);
    go(w, { type: 'choose', mission: 'm_pintadas_ascensor', choice: 'chivarse' });
    expect(w.residents[w.playerId]!.relations).toEqual([
      { with: 'res_cotilla_01', affinity: 10, trust: 0 },
      { with: 'res_nino_01', affinity: -20, trust: 0 },
    ]);
    expect(w.missions.find((x) => x.id === 'm_pintadas_ascensor')!.state).toBe('done');
    expect(w.residents.res_nino_01!.location).toBe('blk_p1_b'); // vuelve a casa
    expect(w.missions.find((x) => x.id === 'm_venganza_nino')!.startAtTick).toBe(w.tick + 1440);
  });

  it('si no llegas en 30 minutos, el niño se sale con la suya y la misión falla', () => {
    const w = createWorld(content, 'slice');
    reachPintadas(w);
    drainEvents(w);
    for (let i = 0; i < 30; i++) tick(w, content);
    expect(w.missions.find((x) => x.id === 'm_pintadas_ascensor')!.state).toBe('active');
    tick(w, content);
    expect(w.missions.find((x) => x.id === 'm_pintadas_ascensor')!.state).toBe('failed');
    expect(drainEvents(w).find((e) => e.type === 'mission_failed')?.data).toMatchObject({ reason: 'timeout' });
    expect(w.residents.res_nino_01!.location).toBe('blk_p1_b');
  });

  it('una misión con retraso se activa cuando llega su hora', () => {
    const w = createWorld(content, 'slice');
    reachPintadas(w);
    go(w, { type: 'move', resident: w.playerId, to: `blk_p${floorOf(w, playerHome(w))}_pasillo` });
    const f = floorOf(w, playerHome(w));
    for (const to of Array.from({ length: f }, (_, i) => `blk_p${f - i}_nucleo`)) go(w, { type: 'move', resident: w.playerId, to });
    go(w, { type: 'choose', mission: 'm_pintadas_ascensor', choice: 'chivarse' });
    const m = w.missions.find((x) => x.id === 'm_venganza_nino')!;
    expect(m.state).toBe('pending');
    w.tick = m.startAtTick - 1;
    drainEvents(w);
    tick(w, content);
    expect(m.state).toBe('active');
    expect(drainEvents(w).find((e) => e.type === 'step_started')?.data).toMatchObject({ dialog: 'dlg_venganza' });
  });

  it('todo el recorrido es determinista y serializable', () => {
    const run = () => {
      const w = createWorld(content, 'slice');
      reachPintadas(w);
      for (let i = 0; i < 40; i++) tick(w, content);
      return JSON.stringify(w);
    };
    expect(run()).toBe(run());
    expect(JSON.parse(run()).missions).toHaveLength(3); // bienvenida, ascensor y pintadas
  });
});
