import { beforeAll, describe, expect, it } from 'vitest';
import { fileURLToPath } from 'node:url';
import { NullEngine, Scene, UniversalCamera, Vector3 } from '@babylonjs/core';
import { loadContentFromDir } from '@vecinos/content/node';
import type { Content } from '@vecinos/content';
import { applyEffects, createWorld, playerHome } from '@vecinos/sim';
import { createActors } from '../src/actors';
import { createBuilding } from '../src/building';
import { CameraRig } from '../src/camera';
import { PlayerLogic } from '../src/player-logic';

let content: Content;
beforeAll(() => {
  const { content: c, issues } = loadContentFromDir(fileURLToPath(new URL('../../content/data', import.meta.url)));
  expect(issues).toEqual([]);
  content = c;
});

function setup() {
  const world = createWorld(content, 'slice');
  const scene = new Scene(new NullEngine());
  return { world, scene, building: createBuilding(scene, world, content), actors: createActors(scene, world), logic: new PlayerLogic(world, content) };
}

describe('escena de humo (motor nulo)', () => {
  it('construye el edificio: viviendas en corte, con puerta y candado solo mientras están bloqueadas', () => {
    const { world, scene, building } = setup();
    building.paint();
    const home = playerHome(world);
    const other = home === 'blk_p4_d' ? 'blk_p4_c' : 'blk_p4_d';
    expect(scene.getMeshByName(`${home}_puerta`)!.isEnabled()).toBe(false);
    expect(scene.getMeshByName(`${other}_puerta`)!.isEnabled()).toBe(true);
    expect(scene.getMeshByName(`${other}_candado`)!.isEnabled()).toBe(true);
    applyEffects(world, content, [{ op: 'unlock', target: other }]);
    building.paint();
    expect(scene.getMeshByName(`${other}_puerta`)!.isEnabled()).toBe(false);
    expect(scene.getMeshByName('blk_p3_nucleo')).toBeTruthy();
    expect(scene.getMeshByName('blk_p2_pasillo')).toBeTruthy();
  });

  it('los vecinos aparecen en la escena solo cuando llegan al edificio', () => {
    const { world, scene, actors, logic } = setup();
    actors.update(0.016, logic.position());
    expect(scene.getMeshByName(world.playerId)!.isEnabled()).toBe(true);
    expect(scene.getMeshByName('res_cotilla_01')!.isEnabled()).toBe(false);
    applyEffects(world, content, [{ op: 'unlock', target: 'blk_p1_b', resident: 'res_cotilla_01' }]);
    for (let i = 0; i < 5; i++) actors.update(0.1, logic.position());
    const cot = scene.getMeshByName('res_cotilla_01')!;
    expect(cot.isEnabled()).toBe(true);
    expect(cot.position.y).toBeGreaterThan(2.0); // planta 1
  });

  it('la cámara se coloca de forma estable en los tres niveles', () => {
    const { world, scene, logic } = setup();
    const rig = new CameraRig(new UniversalCamera('cam', new Vector3(0, 0, -30), scene), scene.getEngine(), 5, 5);
    for (const mode of ['edificio', 'planta', 'estancia'] as const) {
      rig.mode = mode;
      for (let i = 0; i < 200; i++) rig.update(0.05, logic.position());
      const p = rig.camera.position;
      expect([p.x, p.y, p.z].every(Number.isFinite)).toBe(true);
      expect(p.z).toBeLessThan(0);
      if (mode === 'estancia') expect(p.z).toBeGreaterThan(-12); // más cerca que la vista general
    }
    expect(world.blocks.blk_p0_portal).toBeDefined();
  });
});
