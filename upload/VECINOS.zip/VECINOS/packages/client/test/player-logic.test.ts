import { beforeAll, describe, expect, it } from 'vitest';
import { fileURLToPath } from 'node:url';
import { loadContentFromDir } from '@vecinos/content/node';
import type { Content } from '@vecinos/content';
import { activeObjective, applyEffects, createWorld, dispatch, drainEvents, playerHome, type World } from '@vecinos/sim';
import { CELL_W, PlayerLogic, type Input } from '../src/player-logic';

let content: Content;
beforeAll(() => {
  const { content: c, issues } = loadContentFromDir(fileURLToPath(new URL('../../content/data', import.meta.url)));
  expect(issues).toEqual([]);
  content = c;
});

const NONE: Input = { left: false, right: false, up: false, down: false };
const DT = 1 / 60;

function setup() {
  const world = createWorld(content, 'slice');
  return { world, p: new PlayerLogic(world, content) };
}
const run = (p: PlayerLogic, seconds: number, input: Partial<Input> = {}) => {
  for (let t = 0; t < seconds; t += DT) p.update(DT, { ...NONE, ...input });
};
function walkTo(p: PlayerLogic, x: number) {
  for (let i = 0; i < 60 * 20 && Math.abs(p.x - x) > 0.06; i++) p.update(DT, { ...NONE, right: x > p.x, left: x < p.x });
  expect(Math.abs(p.x - x)).toBeLessThanOrEqual(0.06);
}
const centerOf = (w: World, id: string) => (w.blocks[id]!.cell.col + w.blocks[id]!.size.w / 2) * CELL_W;
const loc = (w: World) => w.residents[w.playerId]!.location;

describe('movimiento por el edificio', () => {
  it('empieza en el portal, en la planta baja', () => {
    const { world, p } = setup();
    expect(loc(world)).toBe('blk_p0_portal');
    expect(p.position()).toMatchObject({ floor: 0, mode: 'corridor' });
  });

  it('la zona bajo sus pies decide en qué bloque está la simulación', () => {
    const { world, p } = setup();
    walkTo(p, centerOf(world, 'blk_p0_nucleo'));
    expect(loc(world)).toBe('blk_p0_nucleo');
    walkTo(p, centerOf(world, 'blk_p0_trasteros'));
    expect(loc(world)).toBe('blk_p0_trasteros');
  });

  it('sube por la escalera despacio y por el ascensor deprisa cuando funciona', () => {
    const { world, p } = setup();
    walkTo(p, centerOf(world, 'blk_p0_nucleo'));
    p.update(DT, { ...NONE, up: true });
    expect(p.position().climbing).toBe(true);
    run(p, 1.0);
    expect(p.position().climbing).toBe(true); // la escalera tarda 1,6 s
    run(p, 0.7);
    expect(p.position()).toMatchObject({ floor: 1, climbing: false });
    expect(loc(world)).toBe('blk_p1_nucleo');

    applyEffects(world, content, [{ op: 'setParam', target: 'nucleo.elevator_status', value: 'ok' }]);
    p.update(DT, { ...NONE, up: true });
    run(p, 0.7); // el ascensor tarda 0,6 s
    expect(p.position()).toMatchObject({ floor: 2, climbing: false });
    expect(loc(world)).toBe('blk_p2_nucleo');
  });

  it('no sube por encima de la última planta ni baja de la planta baja', () => {
    const { world, p } = setup();
    walkTo(p, centerOf(world, 'blk_p0_nucleo'));
    p.update(DT, { ...NONE, down: true });
    expect(p.position().climbing).toBe(false);
    applyEffects(world, content, [{ op: 'setParam', target: 'nucleo.elevator_status', value: 'ok' }]);
    for (let i = 0; i < 6; i++) {
      p.update(DT, { ...NONE, up: true });
      run(p, 0.7);
    }
    expect(p.position().floor).toBe(4);
  });

  it('no se sale del edificio por los lados', () => {
    const { p } = setup();
    run(p, 5, { left: true });
    expect(p.x).toBeGreaterThan(0);
    run(p, 10, { right: true });
    expect(p.x).toBeLessThan(5 * CELL_W);
  });
});

describe('puertas', () => {
  function toFloor(world: World, p: PlayerLogic, f: number) {
    walkTo(p, centerOf(world, 'blk_p0_nucleo'));
    for (let i = 0; i < f; i++) {
      p.update(DT, { ...NONE, up: true });
      run(p, 1.7);
    }
  }

  it('una puerta con candado no se abre y dice por qué', () => {
    const { world, p } = setup();
    toFloor(world, p, 1);
    const locked = ['a', 'c', 'd'].map((t) => `blk_p1_${t}`).find((id) => id !== playerHome(world))!;
    walkTo(p, centerOf(world, locked));
    expect(p.doorInFront()?.id).toBe(locked);
    expect(p.interact()).toEqual({ type: 'locked', block: locked, reason: 'for_sale', price: null });
    expect(p.mode).toBe('corridor');
    expect(loc(world)).toBe('blk_p1_pasillo');
  });

  it('el aviso de acercarse a una puerta se envía una sola vez por visita', () => {
    const { world, p } = setup();
    toFloor(world, p, 1);
    drainEvents(world);
    const door = 'blk_p1_a';
    walkTo(p, centerOf(world, door));
    run(p, 0.3, { right: true });
    run(p, 0.3, { left: true });
    expect(drainEvents(world).filter((e) => e.type === 'door_approached' && e.data.block === door)).toHaveLength(1);
  });

  it('el tutorial se completa jugando: llamada, escaleras, puerta y entrar en tu piso', () => {
    const { world, p } = setup();
    const home = playerHome(world);
    const floor = world.blocks[home]!.cell.floor;
    expect(dispatch(world, content, { type: 'answer_call', mission: 'm_bienvenida' }).ok).toBe(true);
    toFloor(world, p, floor);
    walkTo(p, centerOf(world, home));
    expect(activeObjective(world, content)!.step).toMatchObject({ type: 'enter', block: home }); // el acercamiento se registró solo
    expect(p.interact()).toEqual({ type: 'entered', block: home });
    expect(p.position()).toMatchObject({ mode: 'inside', insideBlock: home });
    expect(world.missions.find((m) => m.id === 'm_bienvenida')!.state).toBe('done');
    expect(activeObjective(world, content)!.mission).toBe('m_ascensor');
  });

  it('dentro de casa no se sale de las paredes y se sale por la puerta con la misma tecla', () => {
    const { world, p } = setup();
    const home = playerHome(world);
    const floor = world.blocks[home]!.cell.floor;
    toFloor(world, p, floor);
    walkTo(p, centerOf(world, home));
    p.interact();
    run(p, 3, { left: true });
    expect(p.x).toBeGreaterThan(world.blocks[home]!.cell.col * CELL_W);
    run(p, 6, { right: true });
    expect(p.x).toBeLessThan((world.blocks[home]!.cell.col + 1) * CELL_W);
    expect(p.interact()).toEqual({ type: 'exited', block: home });
    expect(loc(world)).toBe(`blk_p${floor}_pasillo`);
  });
});
