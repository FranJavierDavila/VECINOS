import { describe, expect, it } from 'vitest';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import { loadContentFromDir } from '../src/node';
import { buildContent } from '../src/content';

const dir = fileURLToPath(new URL('../data', import.meta.url));

function records(): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  const { content } = loadContentFromDir(dir);
  for (const [folder, bucket] of Object.entries(content))
    for (const [id, value] of Object.entries(bucket as Record<string, unknown>)) out[`data/${folder}/${id}.json`] = structuredClone(value);
  return out;
}

describe('contenido del vertical slice', () => {
  it('se carga y valida sin errores', () => {
    const { content, issues } = loadContentFromDir(dir);
    expect(issues).toEqual([]);
    expect(Object.keys(content.blocks)).toContain('vivienda_estandar');
    expect(Object.keys(content.missions)).toHaveLength(4);
  });

  it('rechaza claves desconocidas (typos en el JSON)', () => {
    const r = records();
    (r['data/blocks/vivienda_estandar.json'] as Record<string, unknown>).soundProofing = 1;
    const { issues } = buildContent(r);
    expect(issues.some((i) => i.file.includes('vivienda_estandar'))).toBe(true);
  });

  it('exige que el id coincida con el nombre del archivo', () => {
    const r = records();
    r['data/rooms/otra_estancia.json'] = r['data/rooms/estancia_bano.json'];
    const { issues } = buildContent(r);
    expect(issues.some((i) => i.message.includes('debe coincidir'))).toBe(true);
  });

  it('detecta referencias rotas entre archivos', () => {
    const r = records();
    delete r['data/layouts/layout_vivienda_v1.json'];
    const { issues } = buildContent(r);
    expect(issues.some((i) => i.message.includes('distribución desconocida'))).toBe(true);
  });

  it('detecta misiones que apuntan a misiones inexistentes', () => {
    const r = records();
    delete r['data/missions/m_venganza_nino.json'];
    const { issues } = buildContent(r);
    expect(issues.some((i) => i.message.includes('misión desconocida "m_venganza_nino"'))).toBe(true);
  });

  it('detecta llamadas con un diálogo inexistente', () => {
    const r = records();
    delete r['data/dialogs/dlg_bienvenida.json'];
    const { issues } = buildContent(r);
    expect(issues.some((i) => i.message.includes('diálogo desconocido "dlg_bienvenida"'))).toBe(true);
  });

  it('detecta un bloque inicial del jugador que no existe', () => {
    const r = records();
    (r['data/scenarios/slice.json'] as { player: { startBlock: string } }).player.startBlock = 'blk_p9_x';
    const { issues } = buildContent(r);
    expect(issues.some((i) => i.path === 'player.startBlock')).toBe(true);
  });

  it('detecta solapes en la plantilla del edificio', () => {
    const r = records();
    const t = r['data/templates/edificio_4x4_nucleo_central.json'] as { rows: { blocks: { col: number; defId: string; tag: string }[] }[] };
    t.rows[3]!.blocks.push({ col: 3, defId: 'vivienda_estandar', tag: 'e' }); // choca con la vivienda C (planta 1..4)
    const { issues } = buildContent(r);
    expect(issues.some((i) => i.message.includes('solapa'))).toBe(true);
  });

  it('el JSON de ejemplo no depende de un archivo concreto', () => {
    const raw = JSON.parse(readFileSync(`${dir}/scenarios/slice.json`, 'utf8'));
    expect(raw.player.homeCandidates).toHaveLength(14);
  });
});
