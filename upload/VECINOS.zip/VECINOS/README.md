# Vecinos · vertical slice (v0.2: tutorial jugable)

Esqueleto técnico del juego de vecinos, siguiendo el documento de modelo de datos y arquitectura.
TypeScript + Zod + Babylon.js, en un monorepo con npm workspaces.

## Puesta en marcha

```bash
npm install
npm run validate    # valida todo el contenido JSON (esquemas + referencias entre archivos)
npm test            # tests del contenido y de la simulación
npm run typecheck   # comprobación de tipos de los tres paquetes
npm run schemas     # regenera los JSON Schema (autocompletado en VS Code)
npm run dev         # visor Babylon.js (WebGPU si hay soporte, WebGL2 si no)
```

## Paquetes

| Paquete | Qué contiene | Depende de |
|---|---|---|
| `packages/content` | Esquemas Zod, cargador/validador y los archivos JSON del catálogo (`data/`) | — |
| `packages/sim` | Núcleo de simulación sin Babylon: mundo, comandos, misiones, efectos, grafo de circulación, influencias, tick | `content` |
| `packages/client` | Lógica del personaje (sin gráficos), visor Babylon.js e interfaz HTML | `content`, `sim` |

Regla: `sim` nunca importa `client`. El estado del mundo (`World`) es JSON puro.

## Contenido (`packages/content/data`)

Una carpeta por tipo: `blocks/`, `rooms/`, `layouts/`, `influences/`, `archetypes/`, `missions/`, `dialogs/`, `templates/`, `scenarios/`.
El `id` de cada archivo debe coincidir con su nombre. Los esquemas son estrictos: una clave mal escrita es un error.
El validador comprueba además las referencias entre archivos (distribuciones, estancias, misiones, bloques,
residentes, parámetros) y la geometría de la plantilla (límites y solapes por capa).

Convención de ids de bloque al expandir una plantilla: `blk_p{planta}_{tag}` (p. ej. `blk_p3_c`, `blk_p1_nucleo`, `blk_p0_portal`).

Para añadir un tipo de bloque: crea `data/blocks/<id>.json`, úsalo en una plantilla y ejecuta `npm run validate`.

## Qué hay implementado

**Contenido y modelo**
- Esquemas Zod de bloques, estancias, distribuciones, influencias, arquetipos, misiones, diálogos, plantillas y escenarios.
- Validación entre archivos (ids, diálogos, residentes, parámetros, geometría de la plantilla).

**Simulación (`sim`)**
- Mundo desde un escenario: edificio de 5 plantas, una sola vivienda desbloqueada (elegida con la semilla), ascensor roto, jugador en el portal.
- **Comandos**: `move`, `approach`, `answer_call`, `choose`. Son el único camino de las órdenes del jugador: `dispatch` valida, emite eventos y avanza las misiones.
- **Reglas de circulación** (`canMove`): en una planta se pasa siempre por el pasillo; entre plantas, de núcleo a núcleo contiguo; una vivienda con candado rechaza la entrada (`door_locked`).
- **Motor de misiones**: activación por escenario, por efecto (con retraso) o por disparador; enlace de roles por arquetipo y parentesco (`parentOf`); pasos `phone_call`, `reach`, `enter` y `catch_in_act` (con ventana de tiempo y caducidad); decisiones con efectos; `onComplete`.
- Efectos: `setParam`, `unlock` (también `availability` para poner un piso a la venta), `addRelation`, `startMission`, `addFunds`, `revealParams`, `hideParams`, `grantFavor`. `openJunta` y `startMinigame` solo emiten evento.
- Grafo de circulación con tiempos de viaje, influencias por adyacencia (ruido, agua), parámetros por niveles, tick determinista de un minuto de juego.

**Cliente (`client`)**
- `player-logic.ts`: personaje sin gráficos (zona bajo los pies, puerta delante, escalera lenta o ascensor rápido, entrar y salir). Cada cambio de bloque pasa por `dispatch`.
- Visor Babylon.js: viviendas en corte con panel y candado mientras están bloqueadas, pasillo delante, núcleo en rojo con el ascensor roto, vecinos como cápsulas, cámara de tres niveles que sigue al jugador y se acerca sola al entrar o salir de casa.
- Interfaz HTML: teléfono con diálogos, panel de decisiones, objetivo actual, avisos y valores de tu vivienda por niveles.

## Qué falta (a propósito)

- IA de residentes: los vecinos solo aparecen y van adonde dicen las misiones, sin necesidades ni rutinas.
- Junta de vecinos y derramas (`openJunta` solo avisa; arreglar el ascensor ocurre al elegir "convocar la junta").
- El campo `via: "shaft"` del agua está en el esquema, pero la simulación aún propaga por adyacencia normal.
- Minijuegos; textos como claves de localización (hoy `title`, `label` y los diálogos son texto literal).
- Interiores de vivienda (la estancia es una caja), prefabs reales, animaciones, audio, guardado en disco, Electron/Steam, multijugador.
- El visor no se ha probado en un navegador real: la lógica y una escena con motor nulo sí tienen tests.

## Cómo se juega el tutorial

1. Suena el teléfono: `Espacio` avanza el diálogo y al colgar empieza el recorrido.
2. Muévete con `A`/`D` hasta la zona de la escalera (el núcleo) y sube con `W`. Con el ascensor roto tarda 1,6 s por planta.
3. En la planta de tu piso, ponte delante de tu puerta y pulsa `E`. Las puertas con candado se sacuden y avisan.
4. Dentro, la cámara se acerca sola; `E` para salir. Llegan los vecinos y suena la llamada del ascensor.
5. Elige "convocar una junta": se arregla el ascensor (sube más rápido y cuesta 300 de los fondos) y se revela el nivel 2 de parámetros.
6. Aparece el niño en el núcleo de la planta 1: tienes 30 minutos de juego (30 s reales) para pillarlo. Entonces eliges qué hacer.

Teclas `1`, `2`, `3` para forzar la cámara de edificio, planta o estancia. El panel de depuración tiene un botón de fiesta y otro para avanzar el tiempo.
